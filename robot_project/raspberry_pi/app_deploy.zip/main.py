"""FastAPI backend — SRS-compliant (Sections 10.1, 7.x, 8.2, 8.3, 9.x)."""
import subprocess
import asyncio
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query
from starlette.websockets import WebSocketState
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .database import init_db, get_db
from .auth import login as auth_login, require_user, require_admin, verify_token
from .missions import create_mission, get_mission, run_mission, log_event
from . import robot_link  # loads real1_link.env + ROS env before rclpy
from .ros_monitor import start_monitor
from . import teleop

# ── Init ──────────────────────────────────────────────────────────────────
init_db()

app = FastAPI(title="Robot Control API", version="2.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# ── Shared state (in-memory, updated by ROS 2 monitor + endpoints) ────────────────
robot_state: dict = {
    "connection": "connected",      # API link (tablet ↔ Pi backend)
    "status": "idle",
    "battery": 0,
    "battery_voltage": 0.0,
    "pose": {"x": 0.0, "y": 0.0, "theta": 0.0},
    "current_action": None,         # None | navigating | mission | teleop
    "destination": None,
    "current_mission": None,
    "ros_running": False,
    "message": "System idle",
    # Node health (FR-STAT-4)
    "node_health": {
        "robot_driver": "unknown",
        "robotBridge": "unknown",
        "lidar_driver": "unknown",
        "nav2": "unknown",
    },
}

ros_process: Optional[subprocess.Popen] = None
gamepad_process: Optional[subprocess.Popen] = None
_bridge_output: list[str] = []


def _log_line(severity: str, message: str) -> None:
    log_event(severity, "ros_launch", message)


def _stop_gamepad() -> None:
    global gamepad_process
    if gamepad_process and gamepad_process.poll() is None:
        gamepad_process.terminate()
        try:
            gamepad_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            gamepad_process.kill()
    gamepad_process = None
    teleop.stop()


def _start_gamepad() -> str:
    """Start optional Pi gamepad script; always enable API cmd_vel teleop."""
    global gamepad_process
    teleop.enable_teleop(True)
    if gamepad_process and gamepad_process.poll() is None:
        return "gamepad already running — tablet joystick active"

    proc, msg = robot_link.try_start_gamepad()
    if proc is None:
        log_event("info", "teleop", msg)
        return msg

    gamepad_process = proc
    script = os.path.basename(robot_link.resolve_gamepad_path() or "gamepad.py")
    log_event("info", "teleop", f"Started {script} (PID {gamepad_process.pid})")

    def _on_exit(code: int):
        global gamepad_process
        if gamepad_process and gamepad_process.poll() is not None:
            log_event(
                "error" if code != 0 else "info",
                "teleop",
                f"{script} exited (code={code})",
            )
            gamepad_process = None
            if robot_state.get("current_action") == "teleop":
                robot_state["message"] = f"{script} stopped — tablet joystick still active"

    robot_link.watch_process(
        gamepad_process, _on_exit, log_fn=_log_line, source="gamepad"
    )
    return f"{script} running — tablet joystick active"

# Load destinations (Appendix A format: {"Kitchen": {"x": 2.1, "y": 0.5, "theta": 0}})
DEST_FILE = os.path.join(os.path.dirname(__file__), "destinations.json")
if os.path.exists(DEST_FILE):
    with open(DEST_FILE) as f:
        DESTINATIONS: dict = json.load(f)
else:
    DESTINATIONS = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get_setting(key: str, default: str = "") -> str:
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


# ── Start ROS 2 monitor (subscribes to /battery_state, /amcl_pose) ──────────────
start_monitor(robot_state)


# ── Models ────────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class NavigationGoalRequest(BaseModel):
    destination: str

class MissionRequest(BaseModel):
    destinations: list[str]

class DestinationRequest(BaseModel):
    name: str
    x: float
    y: float
    theta: float

class CmdVelRequest(BaseModel):
    linear: float = 0.0   # m/s forward (+) / back (-)
    angular: float = 0.0  # rad/s left (+) / right (-)

class TeleopEnableRequest(BaseModel):
    enabled: bool


# ── Auth ──────────────────────────────────────────────────────────────────────
@app.post("/auth/login")  # FR-AUTH-1/2 — no auth required
def login(req: LoginRequest):
    return auth_login(req.username, req.password)


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"ok": True}


@app.get("/ws")
def websocket_info():
    """Help verify the API exposes the live status WebSocket."""
    return {
        "websocket": "/ws/status",
        "example": "ws://<pi-ip>:8000/ws/status?token=<jwt-from-login>",
        "fallback_rest": "GET /robot/status (poll every 1s if WebSocket blocked)",
    }


def _status_payload() -> dict:
    return {
        "connection": robot_state["connection"],
        "pose": robot_state["pose"],
        "current_action": robot_state["current_action"],
        "destination": robot_state["destination"],
        "status": robot_state["status"],
        "message": robot_state["message"],
        "ros_running": robot_state["ros_running"],
        "node_health": robot_state["node_health"],
        "current_mission": robot_state.get("current_mission"),
    }


@app.get("/robot/link-check")
def link_check(user: dict = Depends(require_user)):
    """Verify Real1 paths on the Pi — use when START fails."""
    return robot_link.validate_link()


@app.get("/robot/ros-check")
def ros_check(user: dict = Depends(require_user)):
    """Check /cmd_vel publishers and subscribers — use when teleop does not move the robot."""
    return robot_link.check_cmd_vel()


# ── Robot control ──────────────────────────────────────────────────────────────
@app.post("/robot/start")  # FR-CTRL-1/2
def start_robot(user: dict = Depends(require_user)):
    global ros_process
    if robot_state["ros_running"]:
        return {"status": "already_running", "message": "ROS 2 stack already running"}

    preflight = robot_link.validate_link()
    if not preflight["ok"]:
        msg = preflight.get("hint", "Real1 path check failed")
        robot_state.update({"status": "error", "message": msg, "connection": "connected"})
        log_event("error", "robot", msg)
        raise HTTPException(status_code=400, detail=msg)

    robot_state["status"] = "launching"
    robot_state["connection"] = "connected"
    robot_state["message"] = "Starting robotBridge..."
    log_event("info", "robot", f"Start requested by {user['sub']}")

    def _launch():
        global ros_process, _bridge_output
        _bridge_output = []
        try:
            ros_process, err = robot_link.try_start_robot_bridge(wait_sec=2.0)
            if ros_process is None:
                msg = f"robotBridge failed: {err}"
                robot_state.update({
                    "ros_running": False,
                    "status": "error",
                    "connection": "connected",
                    "message": msg[:500],
                    "node_health": {k: "dead" for k in robot_state["node_health"]},
                })
                log_event("error", "robot", msg[:500])
                return

            robot_state["ros_running"] = True
            robot_state["status"] = "running"
            robot_state["connection"] = "connected"
            robot_state["message"] = "robotBridge running"
            robot_state["node_health"] = {
                "robot_driver": "unknown",
                "robotBridge": "running",
                "lidar_driver": "unknown",
                "nav2": "unknown",
            }
            log_event(
                "info",
                "robot",
                f"robotBridge started in {robot_link.REAL1_SCRIPTS} (PID {ros_process.pid})",
            )

            robot_link.watch_process(
                ros_process,
                lambda code: _on_ros_exit(code),
                log_fn=_log_line,
                source="robotBridge",
                output_lines=_bridge_output,
            )
        except Exception as exc:
            robot_state["status"] = "error"
            robot_state["connection"] = "connected"
            robot_state["message"] = str(exc)
            log_event("error", "robot", str(exc))

    def _on_ros_exit(code: int):
        global ros_process
        if robot_state["ros_running"]:
            robot_state["ros_running"] = False
            robot_state["status"] = "error"
            robot_state["connection"] = "connected"
            tail = "\n".join(_bridge_output[-6:]).strip()
            msg = f"robotBridge stopped (code={code})"
            if tail:
                msg = f"{msg}: {tail[-400:]}"
            robot_state["message"] = msg[:500]
            robot_state["node_health"] = {k: "dead" for k in robot_state["node_health"]}
            log_event("error", "robot", msg[:500])
        ros_process = None

    threading.Thread(target=_launch, daemon=True).start()
    return {
        "status": "launching",
        "pid": None,
        "message": f"Starting {robot_link.START_COMMAND} in {robot_link.REAL1_WS}",
    }


@app.post("/robot/stop")  # FR-CTRL-4
def stop_robot(user: dict = Depends(require_user)):
    global ros_process
    _stop_gamepad()
    if ros_process:
        ros_process.terminate()
        try:
            ros_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            ros_process.kill()
        ros_process = None
    robot_state.update({
        "ros_running": False, "status": "idle",
        "connection": "connected", "message": "Robot stopped",
        "node_health": {k: "stopped" for k in robot_state["node_health"]},
    })
    log_event("info", "robot", f"Stop requested by {user['sub']}")
    return {"status": "stopped"}


@app.post("/robot/ready")  # FR-CTRL-5
def ready_for_work(user: dict = Depends(require_user)):
    if not robot_state["ros_running"]:
        raise HTTPException(status_code=409, detail="Robot not running. Press START first.")
    robot_state["status"] = "ready"
    robot_state["current_action"] = None
    robot_state["message"] = "Robot ready for work"
    log_event("info", "robot", f"Ready-for-work set by {user['sub']}")
    return {"status": "ready"}


@app.get("/robot/status")  # FR-STAT-1 (snapshot + WebSocket fallback)
def get_status(user: dict = Depends(require_user)):
    return _status_payload()


# ── Destinations ───────────────────────────────────────────────────────────────
@app.get("/destinations")  # FR-NAV-1
def list_destinations(user: dict = Depends(require_user)):
    return {"destinations": list(DESTINATIONS.keys())}


@app.post("/destinations")  # FR-SET-2 — admin only
def add_destination(req: DestinationRequest, user: dict = Depends(require_admin)):
    DESTINATIONS[req.name] = {"x": req.x, "y": req.y, "theta": req.theta}
    with open(DEST_FILE, "w") as f:
        json.dump(DESTINATIONS, f, indent=2)
    log_event("info", "destinations", f"Added destination '{req.name}' by {user['sub']}")
    return {"status": "added", "name": req.name}


@app.delete("/destinations/{name}")  # FR-SET-2
def delete_destination(name: str, user: dict = Depends(require_admin)):
    if name not in DESTINATIONS:
        raise HTTPException(status_code=404, detail="Destination not found")
    del DESTINATIONS[name]
    with open(DEST_FILE, "w") as f:
        json.dump(DESTINATIONS, f, indent=2)
    log_event("info", "destinations", f"Deleted destination '{name}' by {user['sub']}")
    return {"status": "deleted"}


# ── Navigation ────────────────────────────────────────────────────────────────
_nav_cancel_flag = threading.Event()

@app.post("/navigation/goal")  # FR-NAV-2
def send_navigation_goal(req: NavigationGoalRequest, user: dict = Depends(require_user)):
    if not robot_state["ros_running"]:
        raise HTTPException(status_code=409, detail="Robot not running. Press START first.")
    dest = DESTINATIONS.get(req.destination)
    if not dest:
        raise HTTPException(status_code=404, detail=f"Unknown destination: {req.destination}")

    _nav_cancel_flag.clear()
    teleop.stop()
    robot_state.update({
        "status": "navigating",
        "current_action": "navigating",
        "destination": req.destination,
        "message": f"Navigating to {req.destination}",
    })
    log_event("info", "navigation", f"Goal sent to '{req.destination}' by {user['sub']}")

    def _go():
        try:
            proc = subprocess.Popen(
                [
                    sys.executable,
                    os.path.join(os.path.dirname(__file__), "..", "ros2_nodes", "navigate_client.py"),
                    str(dest["x"]), str(dest["y"]), str(dest.get("theta", dest.get("yaw", 0))),
                ],
            )
            while proc.poll() is None:
                if _nav_cancel_flag.is_set():
                    proc.terminate()
                    robot_state["status"] = "running"
                    robot_state["current_action"] = None
                    robot_state["destination"] = None
                    robot_state["message"] = "Navigation cancelled"
                    log_event("info", "navigation", "Navigation cancelled by operator")
                    return
            outcome = "succeeded" if proc.returncode == 0 else "aborted"
            robot_state["status"] = "running" if outcome == "succeeded" else "error"
            robot_state["current_action"] = None
            robot_state["destination"] = None
            robot_state["message"] = f"Navigation {outcome}: {req.destination}"
            log_event(
                "info" if outcome == "succeeded" else "error",
                "navigation",
                f"Navigation to '{req.destination}' {outcome} (rc={proc.returncode})",
            )
        except Exception as exc:
            robot_state["status"] = "error"
            robot_state["message"] = str(exc)
            log_event("error", "navigation", str(exc))

    threading.Thread(target=_go, daemon=True).start()
    return {"status": "accepted", "goal_id": req.destination}


@app.post("/navigation/cancel")  # FR-NAV-5
def cancel_navigation(user: dict = Depends(require_user)):
    _nav_cancel_flag.set()
    log_event("info", "navigation", f"Cancel requested by {user['sub']}")
    return {"status": "cancelling"}


# ── Joystick / cmd_vel teleop ─────────────────────────────────────────────────
@app.post("/teleop/enable")
def teleop_enable(req: TeleopEnableRequest, user: dict = Depends(require_user)):
    if not robot_state["ros_running"]:
        raise HTTPException(status_code=409, detail="Robot not running. Press START first.")
    if req.enabled:
        _nav_cancel_flag.set()
        teleop.stop()
        msg = _start_gamepad()
        robot_state.update({
            "status": "running",
            "current_action": "teleop",
            "destination": None,
            "message": msg,
        })
        log_event("info", "teleop", f"Joystick enabled by {user['sub']}: {msg}")
    else:
        _stop_gamepad()
        robot_state.update({
            "current_action": None,
            "message": "Joystick disabled",
        })
        log_event("info", "teleop", f"Joystick disabled by {user['sub']}")
    return {"status": "enabled" if req.enabled else "disabled", "message": robot_state["message"]}


@app.post("/teleop/cmd_vel")
def teleop_cmd_vel(req: CmdVelRequest, user: dict = Depends(require_user)):
    if not robot_state["ros_running"]:
        raise HTTPException(status_code=409, detail="Robot not running. Press START first.")
    teleop.enable_teleop(True)
    teleop.set_velocity(req.linear, req.angular)
    robot_state.update({
        "current_action": "teleop",
        "message": f"Moving: speed={req.linear:.2f} m/s, turn={req.angular:.2f} rad/s",
    })
    return {"status": "ok", "linear": req.linear, "angular": req.angular}


@app.post("/teleop/stop")
def teleop_stop(user: dict = Depends(require_user)):
    teleop.stop()
    robot_state.update({
        "message": "Robot stopped (cmd_vel zero)",
    })
    log_event("info", "teleop", f"Zero cmd_vel by {user['sub']}")
    return {"status": "stopped"}


@app.get("/teleop/status")
def teleop_status(user: dict = Depends(require_user)):
    return teleop.get_velocity()


# ── Missions ──────────────────────────────────────────────────────────────────
@app.post("/missions")  # FR-MISS-1/2
def create_new_mission(req: MissionRequest, user: dict = Depends(require_user)):
    if not robot_state["ros_running"]:
        raise HTTPException(status_code=409, detail="Robot not running. Press START first.")
    for d in req.destinations:
        if d not in DESTINATIONS:
            raise HTTPException(status_code=404, detail=f"Unknown destination: {d}")
    mission = create_mission(user["sub"], req.destinations)
    run_mission(mission["id"], DESTINATIONS, robot_state)
    return mission


@app.get("/missions/{mission_id}")  # FR-MISS-3
def fetch_mission(mission_id: int, user: dict = Depends(require_user)):
    m = get_mission(mission_id)
    if not m:
        raise HTTPException(status_code=404, detail="Mission not found")
    return m


# ── Logs ───────────────────────────────────────────────────────────────────────
@app.get("/logs")  # FR-LOG-1/2/3
def get_logs(
    severity: Optional[str] = None,
    limit: int = 100,
    user: dict = Depends(require_user),
):
    conn = get_db()
    if severity:
        rows = conn.execute(
            "SELECT * FROM events_log WHERE severity=? ORDER BY id DESC LIMIT ?",
            (severity, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM events_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return {
        "logs": [
            dict(r) for r in rows
        ]
    }


# ── Settings ──────────────────────────────────────────────────────────────────
@app.get("/settings")  # FR-SET-3
def get_settings(user: dict = Depends(require_user)):
    conn = get_db()
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}


@app.put("/settings/{key}")  # admin only
def update_setting(key: str, value: str, user: dict = Depends(require_admin)):
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()
    return {"key": key, "value": value}


# ── WebSocket live telemetry ────────────────────────────────────────────────────
@app.websocket("/ws/status")  # FR-STAT-1 / Section 10.4
async def status_websocket(
    websocket: WebSocket,
    token: str = Query(default=""),
):
    await websocket.accept()

    try:
        verify_token(token or websocket.query_params.get("token", ""))
    except ValueError as exc:
        try:
            await websocket.send_json({"error": "unauthorized", "detail": str(exc)})
            await websocket.close(code=4001)
        except Exception:
            pass
        return

    try:
        while websocket.client_state == WebSocketState.CONNECTED:
            try:
                await websocket.send_json(_status_payload())
            except (WebSocketDisconnect, RuntimeError):
                break
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
