"""Link to the existing Real1 workspace on the Pi — no Real1 code lives in this repo."""
import logging
import os
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)

_LINK_FILE = Path(__file__).resolve().parent.parent / "real1_link.env"


def _load_link_file() -> None:
    if not _LINK_FILE.is_file():
        return
    for line in _LINK_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_link_file()

REAL1_WS = os.environ.get("REAL1_WS", "/home/abpi/Real1")
REAL1_SCRIPTS = os.environ.get(
    "REAL1_SCRIPTS", os.path.join(REAL1_WS, "src", "Real1", "scripts")
)
ROBOT_BRIDGE_SCRIPT = os.environ.get("REAL1_ROBOT_BRIDGE_SCRIPT", "robotBridge.py")
GAMEPAD_SCRIPT = os.environ.get("REAL1_GAMEPAD_SCRIPT", "gamepad.py")
START_COMMAND = os.environ.get("REAL1_START_CMD", "")

SETUP_BASH = os.path.join(REAL1_WS, "install", "setup.bash")
ROBOT_BRIDGE_PATH = os.path.join(REAL1_SCRIPTS, ROBOT_BRIDGE_SCRIPT)
GAMEPAD_PATH = os.path.join(REAL1_SCRIPTS, GAMEPAD_SCRIPT)

_ros_env_cache: Optional[dict] = None


def ros_env() -> dict:
    """Environment with Real1 workspace sourced (cached)."""
    global _ros_env_cache
    if _ros_env_cache is not None:
        return _ros_env_cache.copy()
    env = os.environ.copy()
    env.setdefault("ROS_DOMAIN_ID", "0")
    if os.path.isfile(SETUP_BASH):
        try:
            proc = subprocess.run(
                ["bash", "-lc", f"source {SETUP_BASH} && env"],
                capture_output=True,
                text=True,
                check=True,
                timeout=30,
            )
            for line in proc.stdout.splitlines():
                if "=" in line:
                    key, _, value = line.partition("=")
                    env[key] = value
        except Exception as exc:
            log.warning("Could not source %s: %s", SETUP_BASH, exc)
    _ros_env_cache = env
    return env.copy()


def apply_ros_environment() -> bool:
    """Merge Real1 ROS environment into the current process (before rclpy.init)."""
    if not os.path.isfile(SETUP_BASH):
        return False
    merged = ros_env()
    os.environ.update(merged)
    return True


apply_ros_environment()


def resolve_gamepad_path() -> Optional[str]:
    """Find gamepad script — env name first, then common variants."""
    if os.path.isfile(GAMEPAD_PATH):
        return GAMEPAD_PATH
    if os.path.isdir(REAL1_SCRIPTS):
        for name in ("gamepad.py", "gamePad.py", "Gamepad.py"):
            path = os.path.join(REAL1_SCRIPTS, name)
            if os.path.isfile(path):
                return path
    return None


def validate_link() -> dict:
    checks = {
        "real1_link_env": str(_LINK_FILE),
        "real1_link_env_exists": _LINK_FILE.is_file(),
        "workspace": REAL1_WS,
        "workspace_exists": os.path.isdir(REAL1_WS),
        "setup_bash": SETUP_BASH,
        "setup_bash_exists": os.path.isfile(SETUP_BASH),
        "scripts_dir": REAL1_SCRIPTS,
        "scripts_dir_exists": os.path.isdir(REAL1_SCRIPTS),
        "robot_bridge_script": ROBOT_BRIDGE_PATH,
        "robot_bridge_exists": os.path.isfile(ROBOT_BRIDGE_PATH),
        "gamepad_script": resolve_gamepad_path() or GAMEPAD_PATH,
        "gamepad_exists": resolve_gamepad_path() is not None,
    }
    checks["ok"] = all(
        checks[k]
        for k in (
            "workspace_exists",
            "setup_bash_exists",
            "scripts_dir_exists",
            "robot_bridge_exists",
        )
    )
    if not checks["real1_link_env_exists"]:
        checks["hint"] = f"Copy real1_link.env.example to {_LINK_FILE} on the Pi."
    elif not checks["robot_bridge_exists"]:
        checks["hint"] = f"robotBridge.py not found at {ROBOT_BRIDGE_PATH}"
    elif not checks["setup_bash_exists"]:
        checks["hint"] = f"Run: cd {REAL1_WS} && colcon build"
    else:
        checks["hint"] = "All Real1 paths OK."
    return checks


def _run_bash(body: str) -> subprocess.Popen:
    return subprocess.Popen(
        ["bash", "-lc", body],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=ros_env(),
    )


def bash_in_workspace(inner_command: str, *, cwd_scripts: bool = False) -> subprocess.Popen:
    if cwd_scripts:
        body = (
            f"cd {REAL1_WS} && source {SETUP_BASH} && "
            f"cd {REAL1_SCRIPTS} && exec {inner_command}"
        )
    else:
        body = f"cd {REAL1_WS} && source {SETUP_BASH} && exec {inner_command}"
    return _run_bash(body)


def drain_output(proc: subprocess.Popen, limit: int = 1500) -> str:
    if not proc.stdout:
        return ""
    try:
        return (proc.stdout.read() or "").strip()[-limit:]
    except Exception:
        return ""


def _launch_candidates() -> list[tuple[str, bool]]:
    """Return (command, run_from_scripts_dir) pairs."""
    if START_COMMAND.strip():
        cmd = START_COMMAND.strip()
        if cmd.endswith(".py") and not cmd.startswith("python3"):
            cmd = f"python3 {cmd}"
        use_scripts = ".py" in cmd and not os.path.isabs(cmd.split()[-1])
        return [(cmd, use_scripts)]
    return [
        (f"python3 {ROBOT_BRIDGE_SCRIPT}", True),
        (f"python3 {ROBOT_BRIDGE_PATH}", False),
        ("ros2 run Real1 robotBridge", False),
        ("ros2 run Real1 robot_bridge", False),
        ("ros2 run real1 robot_bridge", False),
    ]


def try_start_robot_bridge(wait_sec: float = 2.0) -> tuple[Optional[subprocess.Popen], str]:
    """Try each launch command; return (process, error_output)."""
    check = validate_link()
    if not check["ok"]:
        return None, check.get("hint", "Real1 link check failed")

    last_output = ""
    for cmd, cwd_scripts in _launch_candidates():
        proc = bash_in_workspace(cmd, cwd_scripts=cwd_scripts)
        time.sleep(wait_sec)
        if proc.poll() is None:
            return proc, ""
        out = drain_output(proc)
        where = f" (cwd={REAL1_SCRIPTS})" if cwd_scripts else f" (cwd={REAL1_WS})"
        last_output = out or f"{cmd}{where} exited with code {proc.returncode}"
    return None, last_output or "All robotBridge launch commands failed"


def check_cmd_vel() -> dict:
    """Report /cmd_vel publishers and subscribers in the ROS graph."""
    try:
        proc = subprocess.run(
            [
                "bash",
                "-lc",
                f"source {SETUP_BASH} && ros2 topic info /cmd_vel -v",
            ],
            capture_output=True,
            text=True,
            timeout=15,
            env=ros_env(),
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        return {
            "ok": proc.returncode == 0,
            "topic": "/cmd_vel",
            "detail": out.strip(),
            "has_subscriber": "Subscription count: 0" not in out
            and "Subscription count:" in out,
        }
    except Exception as exc:
        return {"ok": False, "topic": "/cmd_vel", "error": str(exc)}


def start_gamepad() -> subprocess.Popen:
    path = resolve_gamepad_path()
    if not path:
        raise FileNotFoundError(
            f"No gamepad script in {REAL1_SCRIPTS} "
            f"(tried gamepad.py, gamePad.py — set REAL1_GAMEPAD_SCRIPT in real1_link.env)"
        )
    script = os.path.basename(path)
    return bash_in_workspace(f"python3 {script}", cwd_scripts=True)


def try_start_gamepad() -> tuple[Optional[subprocess.Popen], str]:
    """Start Pi gamepad script if present; return (process or None, message)."""
    path = resolve_gamepad_path()
    if not path:
        return None, "No gamepad script on Pi — using tablet joystick (/cmd_vel)"
    proc = start_gamepad()
    return proc, f"Started {os.path.basename(path)} (PID {proc.pid})"


def stream_process_output(
    proc: subprocess.Popen,
    on_line: Callable[[str, str], None],
    source: str = "process",
) -> None:
    if not proc.stdout:
        return
    for line in proc.stdout:
        line = line.rstrip()
        if not line:
            continue
        sev = (
            "error"
            if any(w in line.lower() for w in ("error", "fatal", "failed", "exception"))
            else "info"
        )
        on_line(sev, f"[{source}] {line[:500]}")


def watch_process(
    proc: subprocess.Popen,
    on_exit: Callable[[int], None],
    log_fn: Optional[Callable[[str, str], None]] = None,
    source: str = "process",
    output_lines: Optional[list[str]] = None,
) -> None:
    def _run():
        if log_fn or output_lines is not None:
            if not proc.stdout:
                code = proc.wait()
                on_exit(code)
                return
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                if output_lines is not None:
                    output_lines.append(line)
                if log_fn:
                    sev = (
                        "error"
                        if any(
                            w in line.lower()
                            for w in ("error", "fatal", "failed", "exception")
                        )
                        else "info"
                    )
                    log_fn(sev, f"[{source}] {line[:500]}")
            on_exit(proc.wait())
        else:
            on_exit(proc.wait())

    threading.Thread(target=_run, daemon=True).start()
