"""Joystick / cmd_vel teleop — delegates to the single-threaded ROS hub."""
from . import ros_hub


def start_publisher() -> None:
    """No-op — ROS hub starts with the API server."""


def enable_teleop(enabled: bool) -> None:
    if not enabled:
        ros_hub.zero_cmd_vel()


def is_enabled() -> bool:
    return ros_hub.get_cmd_vel()["enabled"]


def set_velocity(linear: float, angular: float) -> None:
    ros_hub.set_cmd_vel(linear, angular)


def stop() -> None:
    ros_hub.zero_cmd_vel()


def get_velocity() -> dict:
    return ros_hub.get_cmd_vel()
