"""Single-threaded ROS hub — pose monitor + /cmd_vel publisher (one rclpy spin loop)."""
import logging
import math
import threading

from .ros_context import ensure_rclpy

log = logging.getLogger(__name__)

_started = False
_lock = threading.Lock()
_linear: float = 0.0
_angular: float = 0.0
_cmd_active: bool = False
_hub_node = None


def start(robot_state: dict) -> None:
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_run, args=(robot_state,), daemon=True, name="ros_hub").start()


def set_cmd_vel(linear: float, angular: float) -> None:
    global _linear, _angular, _cmd_active
    linear = max(-1.0, min(1.0, float(linear)))
    angular = max(-2.0, min(2.0, float(angular)))
    with _lock:
        _linear = linear
        _angular = angular
        _cmd_active = linear != 0.0 or angular != 0.0
    _publish_now()


def zero_cmd_vel() -> None:
    global _linear, _angular, _cmd_active
    with _lock:
        _linear = 0.0
        _angular = 0.0
        _cmd_active = False
    _publish_now()


def get_cmd_vel() -> dict:
    with _lock:
        return {
            "linear": _linear,
            "angular": _angular,
            "enabled": _cmd_active,
        }


def _publish_now() -> None:
    node = _hub_node
    if node is None:
        return
    with _lock:
        lx, az, active = _linear, _angular, _cmd_active
    node.publish_cmd(lx if active else 0.0, az if active else 0.0)


def _run(robot_state: dict) -> None:
    global _hub_node
    if not ensure_rclpy():
        log.warning("ROS hub skipped — rclpy not available")
        return
    try:
        import rclpy
        from geometry_msgs.msg import PoseWithCovarianceStamped, Twist
        from rclpy.node import Node

        class RobotHub(Node):
            def __init__(self):
                super().__init__("robot_api_hub")
                self._cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
                self.create_subscription(
                    PoseWithCovarianceStamped, "/amcl_pose", self._pose_cb, 10
                )
                self.create_timer(0.1, self._timer_cb)
                log.info("ROS hub started — publishing /cmd_vel at 10 Hz")

            def publish_cmd(self, linear: float, angular: float) -> None:
                msg = Twist()
                msg.linear.x = linear
                msg.angular.z = angular
                self._cmd_pub.publish(msg)

            def _timer_cb(self) -> None:
                with _lock:
                    lx, az, active = _linear, _angular, _cmd_active
                self.publish_cmd(lx if active else 0.0, az if active else 0.0)

            def _pose_cb(self, msg: PoseWithCovarianceStamped) -> None:
                p = msg.pose.pose
                siny = 2.0 * (
                    p.orientation.w * p.orientation.z
                    + p.orientation.x * p.orientation.y
                )
                cosy = 1.0 - 2.0 * (p.orientation.y ** 2 + p.orientation.z ** 2)
                theta_deg = round(math.degrees(math.atan2(siny, cosy)), 1)
                robot_state["pose"] = {
                    "x": round(p.position.x, 3),
                    "y": round(p.position.y, 3),
                    "theta": theta_deg,
                }

        _hub_node = RobotHub()
        while rclpy.ok():
            rclpy.spin_once(_hub_node, timeout_sec=0.1)
    except Exception as exc:
        log.warning("ROS hub stopped: %s", exc)
    finally:
        _hub_node = None
